using GestioneOrdini.Domain.Enum;

namespace GestioneOrdini.Domain.Models
{
    public class Ordine
    {
        public Guid Id { get; private set; }

        private string _cliente;
        public string Cliente
        {
            get { return _cliente; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException(nameof(Cliente), "Il cliente non può essere vuoto.");

                _cliente = value;
            }
        }

        public DateTime Data { get; private set; }

        private List<ProdottoOrdine> _prodotti;
        public List<ProdottoOrdine> Prodotti
        {
            get { return _prodotti; }
            private set
            {
                if (value == null || value.Count == 0)
                    throw new ArgumentException("L'ordine deve contenere almeno un prodotto.", nameof(Prodotti));

                _prodotti = value;
            }
        }

        public StatoOrdine Stato { get; private set; }

        public decimal TotaleOrdine
        {
            get
            {
                decimal totale = 0;

                foreach (var prodotto in Prodotti)
                    totale += prodotto.PrezzoUnitario * prodotto.Quantita;

                return totale;
            }
        }

        public Ordine(Guid id, string cliente, DateTime data, List<ProdottoOrdine> prodotti, StatoOrdine stato)
        {
            Id = id;
            Cliente = cliente;
            Data = data;
            Prodotti = prodotti;
            Stato = stato;
        }

        public override string ToString()
        {
            return $"Ordine Id: {Id}, Cliente: {Cliente}, Data: {Data}, Stato: {Stato}";
        }

        public override bool Equals(object? obj)
        {
            if (obj is Ordine altro)
                return Id.Equals(altro.Id);

            return false;
        }
    }
}
