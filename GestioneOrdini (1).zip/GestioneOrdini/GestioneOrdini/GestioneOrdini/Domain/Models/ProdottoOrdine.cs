namespace GestioneOrdini.Domain.Models
{
    public class ProdottoOrdine
    {
        private string _nome;
        public string Nome
        {
            get { return _nome; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException(nameof(Nome), "Il nome del prodotto non può essere vuoto.");

                _nome = value;
            }
        }

        private int _quantita;
        public int Quantita
        {
            get { return _quantita; }
            private set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException(nameof(Quantita), "La quantità deve essere maggiore di 0.");

                _quantita = value;
            }
        }

        private decimal _prezzoUnitario;
        public decimal PrezzoUnitario
        {
            get { return _prezzoUnitario; }
            private set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(PrezzoUnitario), "Il prezzo non può essere negativo.");

                _prezzoUnitario = value;
            }
        }

        public ProdottoOrdine(string nome, int quantita, decimal prezzoUnitario)
        {
            Nome = nome;
            Quantita = quantita;
            PrezzoUnitario = prezzoUnitario;
        }

        public override string ToString()
        {
            return $"Prodotto: {Nome}, Quantità: {Quantita}, Prezzo unitario: {PrezzoUnitario} €";
        }

        public override bool Equals(object? obj)
        {
            if (obj is ProdottoOrdine altro)
                return Nome == altro.Nome;

            return false;
        }
    }
}
