namespace GestioneOrdini.Domain.Enum
{
    public enum StatoOrdine
    {
        InAttesa,
        InLavorazione,
        Completato
    }
}
