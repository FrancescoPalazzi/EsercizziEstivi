using GestioneOrdini.Domain.Enum;
using GestioneOrdini.Domain.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GestioneOrdini.Test
{
    [TestClass]
    public class OrdineTest
    {
        [TestMethod]
        public void Ordine_CalcolaTotaleCorrettamente()
        {
            var prodotto1 = new ProdottoOrdine("Mouse", 2, 10m);
            var prodotto2 = new ProdottoOrdine("Tastiera", 1, 20m);

            var prodotti = new List<ProdottoOrdine> { prodotto1, prodotto2 };

            var ordine = new Ordine(
                Guid.NewGuid(),
                "Mario Rossi",
                DateTime.Now,
                prodotti,
                StatoOrdine.InAttesa);

            decimal totaleAtteso = 40m;
            decimal totaleCalcolato = ordine.TotaleOrdine;

            Assert.AreEqual(totaleAtteso, totaleCalcolato);
        }
    }
}
