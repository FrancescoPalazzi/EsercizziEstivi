using System.Globalization;
using GestioneOrdini.Application.Dto;
using GestioneOrdini.Application.Mappers;
using GestioneOrdini.Application.UseCases;
using GestioneOrdini.Domain.Enum;
using GestioneOrdini.Infrastructure.Repositories;

namespace GestioneOrdini.Presentation
{
    internal class Program
    {
        private static async Task Main(string[] args)
        {
            var repository = new OrdineJsonRepository();
            var service = new OrdineUseCases(repository);

            while (true)
            {
                Console.Clear();
                Console.WriteLine("========================================");
                Console.WriteLine("       GESTIONE ORDINI");
                Console.WriteLine("========================================");
                Console.WriteLine("1. Visualizza tutti gli ordini");
                Console.WriteLine("2. Cerca un ordine per ID");
                Console.WriteLine("3. Aggiungi un ordine");
                Console.WriteLine("4. Elimina un ordine");
                Console.WriteLine("0. Esci");
                Console.WriteLine("========================================");
                Console.Write("Scegli un'opzione: ");

                string? scelta = Console.ReadLine();

                switch (scelta)
                {
                    case "1":
                        await VisualizzaTuttiOrdini(service);
                        break;
                    case "2":
                        await CercaOrdinePerId(service);
                        break;
                    case "3":
                        await AggiungiOrdine(service);
                        break;
                    case "4":
                        await EliminaOrdine(service);
                        break;
                    case "0":
                        Console.WriteLine("\nProgramma terminato.");
                        return;
                    default:
                        Console.WriteLine("\nOpzione non valida.");
                        break;
                }

                Console.WriteLine("\nPremi un tasto per tornare al menu.");
                Console.ReadKey();
            }
        }

        private static void StampaOrdine(OrdineDto ordine)
        {
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine($"Ordine #{ordine.Id}");
            Console.WriteLine($"Cliente: {ordine.Cliente}");
            Console.WriteLine($"Data: {ordine.Data:dd/MM/yyyy HH:mm}");
            Console.WriteLine($"Stato: {ordine.Stato}");
            Console.WriteLine("Prodotti:");

            foreach (var prodotto in ordine.Prodotti)
            {
                Console.WriteLine(
                    $"- {prodotto.Nome}, quantità: {prodotto.Quantita}, prezzo unitario: {prodotto.PrezzoUnitario} €");
            }

            var ordineEntity = ordine.ToEntity();
            Console.WriteLine($"Totale ordine: {ordineEntity.TotaleOrdine} €");
        }

        private static async Task VisualizzaTuttiOrdini(OrdineUseCases service)
        {
            Console.WriteLine("\n--- LISTA ORDINI ---");

            var ordini = await service.GetAllOrdiniAsync();

            if (ordini.Count == 0)
            {
                Console.WriteLine("Nessun ordine presente.");
                return;
            }

            foreach (var ordine in ordini)
                StampaOrdine(ordine);
        }

        private static async Task CercaOrdinePerId(OrdineUseCases service)
        {
            Console.WriteLine("\n--- CERCA ORDINE PER ID ---");
            Console.Write("Inserisci l'ID dell'ordine: ");

            string id = Console.ReadLine() ?? string.Empty;

            try
            {
                var ordine = await service.GetOrdineByIdAsync(id);
                StampaOrdine(ordine);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static async Task AggiungiOrdine(OrdineUseCases service)
        {
            Console.WriteLine("\n--- AGGIUNGI ORDINE ---");
            var prodotti = new List<ProdottoOrdineDto>();

            try
            {
                Console.Write("Nome cliente: ");
                string cliente = Console.ReadLine() ?? string.Empty;

                while (true)
                {
                    Console.Write("\nNome prodotto oppure 'fine' per terminare: ");
                    string nome = Console.ReadLine() ?? string.Empty;

                    if (nome.ToLower() == "fine")
                        break;

                    Console.Write("Quantità: ");
                    int quantita = int.TryParse(Console.ReadLine(), out int q) ? q : 0;

                    Console.Write("Prezzo unitario: ");
                    string prezzoLetto = Console.ReadLine() ?? "0";
                    decimal prezzo = decimal.TryParse(prezzoLetto, NumberStyles.Any, CultureInfo.CurrentCulture, out decimal p)
                        ? p
                        : 0;

                    prodotti.Add(new ProdottoOrdineDto(nome, quantita, prezzo));
                }

                if (prodotti.Count == 0)
                {
                    Console.WriteLine("L'ordine deve contenere almeno un prodotto.");
                    return;
                }

                var nuovoOrdine = new OrdineDto(
                    Guid.NewGuid().ToString(),
                    cliente,
                    DateTime.Now,
                    prodotti,
                    StatoOrdine.InAttesa.ToString());

                await service.AggiungiOrdineAsync(nuovoOrdine);
                Console.WriteLine("\nOrdine aggiunto correttamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nErrore: {ex.Message}");
            }
        }

        private static async Task EliminaOrdine(OrdineUseCases service)
        {
            Console.WriteLine("\n--- ELIMINA ORDINE ---");
            Console.Write("Inserisci l'ID dell'ordine da eliminare: ");

            string id = Console.ReadLine() ?? string.Empty;

            try
            {
                await service.EliminaOrdineAsync(id);
                Console.WriteLine("Ordine eliminato correttamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
