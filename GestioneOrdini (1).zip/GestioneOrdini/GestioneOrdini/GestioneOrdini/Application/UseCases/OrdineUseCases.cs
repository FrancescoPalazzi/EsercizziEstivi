using GestioneOrdini.Application.Dto;
using GestioneOrdini.Application.Interfaces;
using GestioneOrdini.Application.Mappers;

namespace GestioneOrdini.Application.UseCases
{
    public class OrdineUseCases
    {
        private readonly IOrdineRepository _repository;

        public OrdineUseCases(IOrdineRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<OrdineDto>> GetAllOrdiniAsync()
        {
            var ordini = await _repository.GetAllOrdiniAsync();
            return ordini.Select(o => o.ToDto()).ToList();
        }

        public async Task<OrdineDto> GetOrdineByIdAsync(string id)
        {
            var ordine = await _repository.GetOrdineByIdAsync(id);

            if (ordine == null)
                throw new Exception($"Ordine con ID {id} non trovato.");

            return ordine.ToDto();
        }

        public async Task AggiungiOrdineAsync(OrdineDto ordineDto)
        {
            var ordine = ordineDto.ToEntity();
            await _repository.AggiungiOrdineAsync(ordine);
        }

        public async Task EliminaOrdineAsync(string id)
        {
            var ordine = await _repository.GetOrdineByIdAsync(id);

            if (ordine == null)
                throw new Exception($"Ordine con ID {id} non trovato.");

            await _repository.EliminaOrdineAsync(id);
        }
    }
}
