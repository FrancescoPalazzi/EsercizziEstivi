using GestioneOrdini.Application.Dto;
using GestioneOrdini.Domain.Models;

namespace GestioneOrdini.Application.Mappers
{
    public static class ProdottoOrdineMapper
    {
        public static ProdottoOrdineDto ToDto(this ProdottoOrdine prodotto)
        {
            if (prodotto == null)
                throw new ArgumentNullException(nameof(prodotto), "Il prodotto non può essere nullo.");

            return new ProdottoOrdineDto(
                prodotto.Nome,
                prodotto.Quantita,
                prodotto.PrezzoUnitario);
        }

        public static ProdottoOrdine ToEntity(this ProdottoOrdineDto prodottoDto)
        {
            if (prodottoDto == null)
                throw new ArgumentNullException(nameof(prodottoDto), "Il DTO del prodotto non può essere nullo.");

            return new ProdottoOrdine(
                prodottoDto.Nome,
                prodottoDto.Quantita,
                prodottoDto.PrezzoUnitario);
        }
    }
}
