using GestioneOrdini.Application.Dto;
using GestioneOrdini.Domain.Enum;
using GestioneOrdini.Domain.Models;

namespace GestioneOrdini.Application.Mappers
{
    public static class OrdineMapper
    {
        public static OrdineDto ToDto(this Ordine ordine)
        {
            if (ordine == null)
                throw new ArgumentNullException(nameof(ordine), "L'ordine non può essere nullo.");

            return new OrdineDto(
                ordine.Id.ToString(),
                ordine.Cliente,
                ordine.Data,
                ordine.Prodotti.Select(p => p.ToDto()).ToList(),
                ordine.Stato.ToString());
        }

        public static Ordine ToEntity(this OrdineDto ordineDto)
        {
            if (ordineDto == null)
                throw new ArgumentNullException(nameof(ordineDto), "Il DTO dell'ordine non può essere nullo.");

            if (!System.Enum.TryParse<StatoOrdine>(ordineDto.Stato, out var stato))
                throw new ArgumentException($"Stato non valido: {ordineDto.Stato}");

            return new Ordine(
                Guid.Parse(ordineDto.Id),
                ordineDto.Cliente,
                ordineDto.Data,
                ordineDto.Prodotti.Select(p => p.ToEntity()).ToList(),
                stato);
        }
    }
}
