using GestioneOrdini.Domain.Models;

namespace GestioneOrdini.Application.Interfaces
{
    public interface IOrdineRepository
    {
        Task<Ordine?> GetOrdineByIdAsync(string id);
        Task<List<Ordine>> GetAllOrdiniAsync();
        Task AggiungiOrdineAsync(Ordine ordine);
        Task EliminaOrdineAsync(string id);
    }
}
