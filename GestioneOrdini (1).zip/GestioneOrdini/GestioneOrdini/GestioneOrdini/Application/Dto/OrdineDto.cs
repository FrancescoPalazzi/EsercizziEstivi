namespace GestioneOrdini.Application.Dto
{
    public record OrdineDto(
        string Id,
        string Cliente,
        DateTime Data,
        List<ProdottoOrdineDto> Prodotti,
        string Stato);
}
