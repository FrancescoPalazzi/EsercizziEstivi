namespace GestioneOrdini.Application.Dto
{
    public record ProdottoOrdineDto(
        string Nome,
        int Quantita,
        decimal PrezzoUnitario);
}
