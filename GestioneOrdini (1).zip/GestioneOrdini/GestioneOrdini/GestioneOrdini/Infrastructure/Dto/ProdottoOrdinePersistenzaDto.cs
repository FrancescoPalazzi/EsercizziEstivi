namespace GestioneOrdini.Infrastructure.Dto
{
    public record ProdottoOrdinePersistenzaDto(
        string Nome,
        int Quantita,
        decimal PrezzoUnitario);
}
