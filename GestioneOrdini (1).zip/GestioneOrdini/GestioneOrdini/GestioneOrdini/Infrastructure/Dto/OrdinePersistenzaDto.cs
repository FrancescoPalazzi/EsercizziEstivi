namespace GestioneOrdini.Infrastructure.Dto
{
    public record OrdinePersistenzaDto(
        string Id,
        string Cliente,
        DateTime Data,
        List<ProdottoOrdinePersistenzaDto> Prodotti,
        string Stato);
}
