using System.Text.Json;
using GestioneOrdini.Application.Interfaces;
using GestioneOrdini.Domain.Models;
using GestioneOrdini.Infrastructure.Dto;
using GestioneOrdini.Infrastructure.Mapper;

namespace GestioneOrdini.Infrastructure.Repositories
{
    public class OrdineJsonRepository : IOrdineRepository
    {
        private readonly string _filePath;
        private List<Ordine> _cache = new();
        private bool _isLoaded;

        public OrdineJsonRepository(string? filePath = null)
        {
            _filePath = filePath ?? Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "GestioneOrdini",
                "ordini.json");

            var cartella = Path.GetDirectoryName(_filePath)!;

            if (!Directory.Exists(cartella))
                Directory.CreateDirectory(cartella);
        }

        private async Task CaricaOrdiniAsync()
        {
            if (_isLoaded)
                return;

            if (!File.Exists(_filePath))
            {
                _cache = new List<Ordine>();
                _isLoaded = true;
                return;
            }

            await using var stream = File.OpenRead(_filePath);

            var dto = await JsonSerializer.DeserializeAsync<List<OrdinePersistenzaDto>>(stream)
                      ?? new List<OrdinePersistenzaDto>();

            _cache = dto.Select(o => o.ToEntity()).ToList();
            _isLoaded = true;
        }

        private async Task SalvaAsync()
        {
            var dto = _cache.Select(o => o.ToPersistenceDto()).ToList();

            await using var stream = File.Create(_filePath);

            await JsonSerializer.SerializeAsync(
                stream,
                dto,
                new JsonSerializerOptions { WriteIndented = true });
        }

        public async Task<List<Ordine>> GetAllOrdiniAsync()
        {
            await CaricaOrdiniAsync();
            return _cache.ToList();
        }

        public async Task<Ordine?> GetOrdineByIdAsync(string id)
        {
            await CaricaOrdiniAsync();

            if (!Guid.TryParse(id, out var guid))
                return null;

            return _cache.FirstOrDefault(o => o.Id == guid);
        }

        public async Task AggiungiOrdineAsync(Ordine ordine)
        {
            await CaricaOrdiniAsync();
            _cache.Add(ordine);
            await SalvaAsync();
        }

        public async Task EliminaOrdineAsync(string id)
        {
            await CaricaOrdiniAsync();

            if (!Guid.TryParse(id, out var guid))
                return;

            var ordine = _cache.FirstOrDefault(o => o.Id == guid);

            if (ordine == null)
                return;

            _cache.Remove(ordine);
            await SalvaAsync();
        }
    }
}
