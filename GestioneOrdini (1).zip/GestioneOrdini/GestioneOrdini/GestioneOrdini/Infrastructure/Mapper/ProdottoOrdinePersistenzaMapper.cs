using GestioneOrdini.Domain.Models;
using GestioneOrdini.Infrastructure.Dto;

namespace GestioneOrdini.Infrastructure.Mapper
{
    public static class ProdottoOrdinePersistenzaMapper
    {
        public static ProdottoOrdinePersistenzaDto ToPersistenceDto(this ProdottoOrdine prodotto)
        {
            if (prodotto == null)
                throw new ArgumentNullException(nameof(prodotto), "Il prodotto non può essere nullo.");

            return new ProdottoOrdinePersistenzaDto(
                prodotto.Nome,
                prodotto.Quantita,
                prodotto.PrezzoUnitario);
        }

        public static ProdottoOrdine ToEntity(this ProdottoOrdinePersistenzaDto prodottoDto)
        {
            if (prodottoDto == null)
                throw new ArgumentNullException(nameof(prodottoDto), "Il DTO di persistenza non può essere nullo.");

            return new ProdottoOrdine(
                prodottoDto.Nome,
                prodottoDto.Quantita,
                prodottoDto.PrezzoUnitario);
        }
    }
}
