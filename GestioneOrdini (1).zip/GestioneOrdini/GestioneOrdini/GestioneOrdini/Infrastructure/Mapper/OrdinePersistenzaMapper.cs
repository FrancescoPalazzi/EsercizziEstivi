using GestioneOrdini.Domain.Enum;
using GestioneOrdini.Domain.Models;
using GestioneOrdini.Infrastructure.Dto;

namespace GestioneOrdini.Infrastructure.Mapper
{
    public static class OrdinePersistenzaMapper
    {
        public static OrdinePersistenzaDto ToPersistenceDto(this Ordine ordine)
        {
            if (ordine == null)
                throw new ArgumentNullException(nameof(ordine), "L'ordine non può essere nullo.");

            return new OrdinePersistenzaDto(
                ordine.Id.ToString(),
                ordine.Cliente,
                ordine.Data,
                ordine.Prodotti.Select(p => p.ToPersistenceDto()).ToList(),
                ordine.Stato.ToString());
        }

        public static Ordine ToEntity(this OrdinePersistenzaDto ordineDto)
        {
            if (ordineDto == null)
                throw new ArgumentNullException(nameof(ordineDto), "Il DTO di persistenza non può essere nullo.");

            if (!System.Enum.TryParse<StatoOrdine>(ordineDto.Stato, out var stato))
                throw new ArgumentException($"Stato non valido: {ordineDto.Stato}");

            return new Ordine(
                Guid.Parse(ordineDto.Id),
                ordineDto.Cliente,
                ordineDto.Data,
                ordineDto.Prodotti.Select(p => p.ToEntity()).ToList(),
                stato);
        }
    }
}
